---
name: redash作成タスク
about: redash作成タスク用
title: ''
labels: redash
assignees: ''

---

**目的**

**取得したいデータの要件**
