## Overview

- Ticket link: github issue, slack request
- Redmine link: link to the issue in redmine

## Root cause
- Describe if this is bug fix & error fix issue

## Design & Solution

- Describe shortly what you did

## Effects

- Feature:
- Screen:

## Review checklist
Performance: https://wiki.zigexn.vn/doku.php?id=performance_checklist
- [ ] Did you minimize the number of requests to the database? Eliminate the N+1 query problem? Are your queries efficient?
- [ ] Did you use a Caching for a result's method or object if it is called many times/used frequently?
- [ ] Put processes that don't need an immediate response into the background processing.
- [ ] Have you added indexes to foreign keys, joint tables, and polymorphic relationships?

Security: https://wiki.zigexn.vn/doku.php?id=security_checklist
- [ ] Did you consider what security vulnerabilities this code is susceptible to?
- [ ] Are authorization and authentication handled in the right way?
- [ ] Is (user) input validated, sanitized, and escaped to prevent security attacks such as cross-site scripting, SQL injection?
- [ ] Is sensitive data like user data, credit card information securely handled and stored?
- [ ] Does this code change reveal some secret information like keys, passwords, or usernames?
- [ ] Is data retrieved from external APIs or libraries checked accordingly?
- [ ] Does error handling or logging expose us to vulnerabilities?

## Test

- Testcase: Link to testcase
- Evidence: Screenshot || Screenrecord

## Notes

- Provide more information to others

## Release steps/Release note
- How to release? need to update enviroment variables? run rake task?...
