# Developer and Technical Lead Guide for Devin

## Core Principles

The main objectives of this guide are:

1. Ensure developers follow a strict process that generates sufficient documentation for future AI Agent autonomy
2. Enable Technical Leads to enforce process compliance
3. Maintain high-quality documentation in Hikakaku CMS for AI context preservation
4. Leverage Devin's capabilities for efficient implementation and quality assurance

## Devin AI Capabilities

Devin offers several advantages over previous AI agents:

1. **Enhanced Code Understanding**: Devin can analyze complex codebases more effectively
2. **Improved Implementation**: Generates higher quality code with fewer iterations
3. **GitHub Integration**: Directly creates and manages PRs with proper CI/CD monitoring
4. **Comprehensive Testing**: Creates robust test cases and implementations
5. **Context Preservation**: Better maintains project context across sessions

## Developer Implementation Flow

### Process Requirements

Developers MUST follow this process to ensure:

- Devin AI fully understands the context and generates highest quality code
- Documentation and Hikakaku CMS are consistently updated after each completed task
- Each step is explicitly confirmed before proceeding to the next
- Feature documentation is properly stored and indexed

### Practical Implementation Guide

#### Step 1: Hikakaku CMS

```
Developer: "Follow .cursor/rules/devin-initialization.md"
```

This command instructs Devin to load all Hikakaku CMS knowledge files:
- `.cursor/knowledge/structure/feature-specification/template.md`
- `.cursor/knowledge/structure/feature-specification/index.md`
- `.cursor/knowledge/structure/feature-summary.md`
- `.cursor/knowledge/structure/project-brief.md`
- `.cursor/knowledge/structure/system-patterns.md`
- `.cursor/knowledge/structure/tech-context.md`

Next, introduce the new requirement:

```
Developer: "Follow @.cursor/rules/0-work-flow-manual-devin.md, new requirement: [describe your requirement]"
```

Devin will analyze the requirement and ask clarifying questions. After answering these questions, you must:

```
Developer: "Update Hikakaku CMS"
```

This creates a new feature file in `.cursor/knowledge/structure/feature-specification/` and updates the index.

**⚠️ MANDATORY**: You must explicitly confirm completion of Step 1 before proceeding.

#### Step 2: Clear Specification

```
Developer: "Create Clear Specification"
```

Devin will create a detailed specification following the template structure. Review the specification carefully and provide feedback until it meets all requirements.

**⚠️ MANDATORY**: You must explicitly confirm completion of Step 2 before proceeding.

#### Step 3: Test Case Creation

```
Developer: "Write Test Cases"
```

Devin will create comprehensive test cases covering:
- Happy path scenarios
- Edge cases
- Error handling
- Performance considerations

Review the test cases and ensure they cover all requirements and edge cases.

**⚠️ MANDATORY**: You must explicitly confirm completion of Step 3 before proceeding.

#### Step 4: Technical Solution Design

```
Developer: "Give Technical Solution"
```

Devin will design a technical solution including:
- Architecture overview
- Component design
- Data flow
- Security considerations
- Performance optimizations

Review the solution and provide feedback until it meets all requirements.

**⚠️ MANDATORY**: You must explicitly confirm completion of Step 4 before proceeding.

#### Step 5: Implementation

```
Developer: "Start Implementation"
```

Devin will implement the solution according to the technical design. Review the code and provide feedback.

After approving the implementation:

```
Developer: "Approved Code and write Unit Test follow previous Test Cases"
```

Devin will create unit tests based on the test cases from Step 3.

**⚠️ MANDATORY**: You must explicitly confirm completion of Step 5 before proceeding.

Finally:

```
Developer: "Completed Task"
```

### Implementation Steps Diagram

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant Devin
    participant GH as GitHub
    participant MB as Hikakaku CMS

    Note over Dev: 🚀 Start Flow

    %% Hikakaku CMS and Initial Requirement Phase
    Dev->>Devin: Ask "Follow .cursor/rules/devin-initialization.md"
    Devin-->>Devin: Load Hikakaku CMS
    Dev->>Devin: Ask "Follow @.cursor/rules/0-work-flow-manual-devin.md, new requirement: xxx"

    Devin->>Devin: Analyze & give Questions
    Dev->>Devin: Read & Answer Questions
    
    Devin->>MB: Create new Context if not exist<br/>(feature-specification/new-feature.md)
    Devin->>MB: Update index.md with new feature
    
    Dev->>Devin: Ask "Update Hikakaku CMS"
    Dev->>Dev: ⚠️ MANDATORY: Confirm Step 1 Complete

    %% Clear Spec Phase
    Dev->>Devin: Ask "Create Clear Specification"
    Devin-->>Devin: Create Specification
    Devin->>MB: Update feature file with specification
    Dev->>Dev: ⚠️ MANDATORY: Confirm Step 2 Complete

    %% Test Case Phase
    Dev->>Devin: Ask "Write Test Cases"
    Devin-->>Devin: Write Test Cases
    Devin->>MB: Update feature file with Test Cases
    Dev->>Dev: ⚠️ MANDATORY: Confirm Step 3 Complete

    %% Technical Solution Phase
    Dev->>Devin: Ask "Give Technical Solution"
    Devin-->>Devin: Create Technical Solution
    Dev->>Devin: Review & Feedback Solution
    Devin->>MB: Update feature file with Technical Solution
    Dev->>Dev: ⚠️ MANDATORY: Confirm Step 4 Complete

    %% Implementation Phase
    Dev->>Devin: Ask "Start Implementation"
    Devin-->>Devin: Write Code
    Dev->>Devin: Review Code & Feedback
    Devin->>GH: Create PR with implementation
    GH-->>Devin: CI/CD Status
    Dev->>Devin: Say "Approved Code and write Unit Test follow previous Test Cases"
    Devin-->>Devin: Write Unit Test
    
    %% Finalization Phase
    Devin->>MB: Update Hikakaku CMS with implementation details
    Dev->>Dev: ⚠️ MANDATORY: Confirm Step 5 Complete
    Dev->>Devin: Say "Completed Task"
```

## Feature Documentation Management

### Creating New Feature Files

For each new feature:

1. Create a file in `.cursor/knowledge/structure/feature-specification/` using the template
2. Name the file descriptively (e.g., `user-authentication.md`)
3. Include all required sections:
   - Status (Current Status, Author, Last Updated)
   - Business Requirements
   - TODO List
   - Active Decisions
   - Technical Solution
   - Data Flow (Mermaid chart)
   - Security Patterns
   - Test Cases

Example command to Devin:
```
"Create a new feature file for user authentication following the template"
```

### Updating the Index File

After creating or updating a feature file:

1. Update `.cursor/knowledge/structure/feature-specification/index.md`
2. Add a new row with:
   - Feature name
   - Current status
   - Last updated date
   - Link to the feature file

Example command to Devin:
```
"Update the feature index with the new user authentication feature"
```

### Hikakaku CMS Updates

After each workflow step:

1. Update the feature-specific file with new information
2. Update the index file to reflect the current status

Example command to Devin:
```
"Update Hikakaku CMS with the completed test cases for user authentication"
```

## Technical Lead Review Process

### Primary Responsibilities

Technical Leads MUST:

1. Ensure developers strictly follow the implementation process
2. Verify complete documentation for each Pull Request
3. Validate Hikakaku CMS updates reflect code changes
4. Reject PRs with insufficient documentation
5. Verify each step was properly confirmed before proceeding

### Review Flow

```mermaid
sequenceDiagram
    participant Devin
    participant Dev as Developer
    participant TL as Tech Lead
    participant GH as GitHub

    Note over Dev: 🚀 Start Flow

    Dev->>Devin: Follow Implementation Flow
    Dev->>Dev: Review Document / Hikakaku CMS changes
    Devin->>GH: Create Pull Request
    Dev->>TL: Request PR Review

    loop Review Document and Code
      TL->>TL: Hikakaku CMS / Document updated?
      TL->>TL: Feature file and index updated?
      TL->>TL: Evaluate Solution / Code
      TL->>GH: Add review comments
      Dev->>Devin: Address feedback
      Devin->>GH: Update PR
    end

    TL->>GH: Approve PR
```

### Documentation Review Checklist

Technical Leads must verify:

1. Hikakaku CMS is updated with:
   - New business logic
   - Technical decisions
   - Architecture changes
   - New Code changes
   - Codebase and Feature Summary changes

2. Feature documentation is properly stored:
   - New feature file created based on template
   - Index file updated with feature information
   - All sections of feature file completed

3. Implementation Process has:
   - Complete requirements documentation
   - Comprehensive test cases
   - Detailed technical solution
   - Updated unit tests
   - Mandatory step confirmations

4. Code Changes align with:
   - Documented requirements
   - Approved technical solution
   - Test coverage requirements
   - GitHub integration best practices

### GitHub Integration Best Practices

When working with GitHub in the implementation phase:

1. **Branch Naming**:
   - Use `feature/[feature-name]` for feature branches
   - Example: `feature/user-authentication`

2. **Commit Messages**:
   - Follow the format: `[Feature] Brief description of changes`
   - Example: `[User Authentication] Add login form validation`

3. **PR Description**:
   - Include feature overview
   - Implementation approach
   - Testing performed
   - Screenshots/demos if applicable

4. **CI/CD Monitoring**:
   - Devin will automatically monitor CI/CD status
   - Address any failures before requesting review

5. **Code Review Process**:
   - Technical Lead adds review comments in GitHub
   - Developer instructs Devin to address feedback
   - Devin updates PR with fixes

Example command to Devin for addressing feedback:
```
"Address the PR feedback about input validation"
```

### Enforcement Policy

1. PRs missing documentation MUST be rejected
2. Documentation quality is as important as code quality
3. All technical decisions must be documented for AI context
4. No exceptions to documentation requirements are allowed
5. Steps without explicit confirmation must be rejected

## Troubleshooting Common Issues

### Issue: Devin doesn't understand the context

**Solution**: Ensure Hikakaku CMS is properly loaded with:
```
"Follow .cursor/rules/devin-initialization.md"
```

### Issue: Feature documentation is incomplete

**Solution**: Review the feature file against the template and update missing sections:
```
"Update the user authentication feature file with missing security patterns"
```

### Issue: CI/CD failures in implementation

**Solution**: Ask Devin to analyze and fix the issues:
```
"Fix the CI failures related to the failing tests"
```

### Issue: Need to return to a previous step

**Solution**: Explicitly state which step you need to return to:
```
"We need to go back to Step 3 to update the test cases for edge case X"
```

## Best Practices for Effective Devin Collaboration

1. **Be Explicit**: Always specify which step you're working on
2. **Confirm Steps**: Always confirm completion of each step before proceeding
3. **Review Thoroughly**: Carefully review all outputs before approving
4. **Maintain Documentation**: Keep Hikakaku CMS updated after each significant change
5. **Use Specific Commands**: Use the exact command phrases shown in this guide
6. **Provide Clear Feedback**: When reviewing, be specific about what needs to change
7. **Monitor GitHub Integration**: Review PR descriptions and CI status

## Quality Checklist Enforcement

The workflow includes manual quality checklists to ensure documentation completeness before step transitions:

1. **Documentation Verification**: Technical Leads must verify:
   - Required sections for each step are present
   - Feature is properly indexed
   - Documentation follows template structure

2. **Step Transition Validation**:
   - Quality checklist must be reviewed before step transition
   - Step transition is blocked if documentation is incomplete
   - Technical Lead provides specific feedback on missing elements

3. **Integration with PR Process**:
   - PR reviews include documentation quality assessment
   - Technical Lead reviews are blocked until quality checklists pass
   - Documentation quality is considered as important as code quality

### Using Quality Checklists

To ensure your documentation meets the quality requirements:

```
Developer: "Let's review the quality checklist for the user authentication feature"
```

Devin will help you review the feature documentation against the quality checklist and identify any issues that need to be addressed before proceeding to the next step.
