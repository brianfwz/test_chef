# Manual Workflow Description for Devin (AI Agent)

**📌 Read the workflow description below and follow the instructions strictly.**

## 🧠 Devin AI Agent – Based Workflow Guide

### 🎯 Core Responsibilities

1. **Strictly follow** the steps defined in the workflow.
2. **Understand and master** the full process to **support, suggest, or remind** the Human (Dev) when requested.
3. **Apply the correct Rule** for each defined Step.
4. **Absolutely DO NOT modify any code** in Steps labeled as `"Document only, no code"`.
5. **Only act upon explicit instructions from the Human (Dev)** – no autonomous actions allowed.
6. **Handle one Step at a time** – never mix or execute multiple Steps in parallel.
7. **Leverage Devin's capabilities** for code review, implementation, testing, and GitHub integration.
8. **Ensure documentation quality** at each step to maintain a comprehensive knowledge base.

### ❗ Step Permissions Summary

| Step | Rule Name | Code Allowed? | Description | Quality Checklist |
| ---- | --------- | ----------- | ----------- | ----------- |
| 1    | Hikakaku CMS | ❌ No         | Load Hikakaku CMS knowledge only | ✓ All project knowledge loaded<br>✓ Current state understood<br>✓ Dependencies identified |
| 2    | Clear Spec  | ❌ No         | Documentation only | ✓ All requirements clarified<br>✓ Edge cases identified<br>✓ Acceptance criteria defined<br>✓ API endpoints documented |
| 3    | Test Case   | ❌ No         | Write test cases only | ✓ Happy path tests defined<br>✓ Edge case tests included<br>✓ Error handling tests covered<br>✓ Performance considerations noted |
| 4    | Tech Lead   | ❌ No         | Design technical solution only | ✓ Architecture clearly defined<br>✓ Data flow documented<br>✓ Security considerations addressed<br>✓ Performance optimizations identified |
| 5    | Developer   | ✅ Yes        | Full code + documentation responsibilities | ✓ Code follows best practices<br>✓ Unit tests implemented<br>✓ Documentation updated<br>✓ PR created with proper description |

---

### 🔐 Execution Behavior & Controls

**Important:** Provide outputs and update Hikakaku CMS after each Step

- **Manual Trigger Only:** Devin only acts **when explicitly instructed by the Human (Dev)**.
- **Single-Step Mode:** Only one Step is active at a time. Devin must **not mix or execute across Steps**.
- **Mandatory Step Confirmation:** Each step **MUST be explicitly confirmed as complete** by the Human (Dev) before proceeding to the next step. No exceptions.
- **Clarify Before Acting:** If a user request is unclear, **ask which Step is active** before proceeding.
- **Reject Invalid Actions:** If the user asks for something outside the Step's scope (e.g., coding during Step 1–3), **refuse and warn**.
- **Error Handling:** If errors are detected in a previous step, **document the issue** and suggest reverting to the appropriate step.
- **CI/CD Integration:** For implementation steps, utilize Devin's GitHub integration for PR creation and CI monitoring.

### 🛠️ Rule References

Each step in the workflow has a corresponding rule file that defines the specific responsibilities and behaviors:

1. **Step 1: Hikakaku CMS** - Rule defined in `.cursor/rules/4-hikakaku-cms--agent.mdc`
2. **Step 2: Clear Spec** - Rule defined in `.cursor/rules/1-clear-spec--agent.mdc`
3. **Step 3: Test Case** - Rule defined in `.cursor/rules/2-test-case--agent.mdc`
4. **Step 4: Tech Lead** - Rule defined in `.cursor/rules/3-tech-lead--agent.mdc`
5. **Step 5: Developer** - Rule defined in `.cursor/rules/5-developer--agent.mdc`

**Important:** Always refer to these rule files for detailed responsibilities and behaviors of each step.

## 🧠 Workflow Sequence Diagram

```mermaid
sequenceDiagram
    participant AI as 🤖 Devin AI
    participant Human as 👨‍💻 Human (Dev)
    participant QA_BE as 👥 QA Lead &<br/>Backend Senior
    participant Tech as 👨‍💻 Technical Lead
    participant MB as 📚 Hikakaku CMS
    participant CS as ⚙️ Codebase & Feature Summary
    participant GH as 🔄 GitHub

    Note over Human: 🚀 Start Flow

    activate AI
    activate Human
    Human->>QA_BE: Give Specifications

    AI->>MB: 💡 Step 1: Load Hikakaku CMS
    activate MB
    MB->>Human: Project knowledge and current state
    deactivate MB

    Human->>QA_BE: 💡 Step 2: Clear Specification
    Note over QA_BE: Use Rule "Clear Spec"<br/><Document only, no code>
    deactivate Human

    activate QA_BE
    loop Until No Questions
        QA_BE<<->>Human: Clear Spec Process
    end
    deactivate QA_BE

    activate AI
    AI->>MB: Create new Context if not exist<br/><feature-specification/> (follow template.md)

    activate QA_BE
    QA_BE->>MB: 💡 Step 2.1: Update Hikakaku CMS<br/>(with final specification detail)
    deactivate QA_BE

    Note over AI: ✓ Verify Spec Quality<br/>Using Checklist
    
    activate Human
    Human->>Human: ⚠️ MANDATORY: Confirm Step 2 Complete
    
    Human->>QA_BE: 💡 Step 3: Request Test Cases

    Note over QA_BE: Use Rule "Test Case"<br/><Document only, no code>

    activate QA_BE
    loop Until Approved
        QA_BE->>Human: Test Case Process
        Human->>QA_BE: Review & Feedback
    end

    QA_BE->>MB: 💡 Step 3.1: Update Hikakaku CMS<br/>(with test cases "feature-specification/[current-context].md (Test Cases)")
    deactivate QA_BE

    Note over AI: ✓ Verify Test Case Quality<br/>Using Checklist
    
    Human->>Human: ⚠️ MANDATORY: Confirm Step 3 Complete

    Human->>Tech: 💡 Step 4: Request Technical Solution
    activate Tech
    Note over Tech: Use Rule "Tech Lead"<br/><Document only, no code>

    loop Until Solution Approved
        Tech->>Human: Propose Solution
        Human->>Tech: Review & Feedback
    end

    Tech->>MB: 💡 Step 4.1: Update Hikakaku CMS<br/>(with technical solution/design "feature-specification/[current-context].md (Tech Solution)")
    deactivate Tech

    Note over AI: ✓ Verify Solution Quality<br/>Using Checklist
    
    Human->>Human: ⚠️ MANDATORY: Confirm Step 4 Complete

    Human->>AI: 💡 Step 5: Request Implementation
    activate AI
    Note over AI: Use Rule "Developer"<br/><change files, write code>

    AI->>CS: Load Codebase & Feature Summary

    loop Until Code Approved
        AI->>Human: Implementation Feature & Unit Test follow Test Cases
        Human->>AI: Review Code & Feedback
    end

    AI->>GH: Create PR with implementation
    GH-->>AI: CI/CD Status
    
    Note over AI: Monitor CI/CD<br/>Address any issues
    
    Human->>Human: ⚠️ MANDATORY: Confirm Step 5 Complete

    deactivate Human

    AI->>MB: 💡 Step 5.1: Update Hikakaku CMS<br/>(ALL Hikakaku CMS)
    AI->>CS: 💡 Step 5.2: Update Document<br/>(Codebase Overview, Feature Summary & Completed Context)
    deactivate AI
```

## 🔄 Error Handling Procedures

### Handling Issues Between Steps

If issues are discovered in a later step that require revisiting an earlier step:

1. **Document the Issue**: Clearly describe what was found and why it requires revisiting a previous step
2. **Identify Impact**: Assess how this affects the current and future steps
3. **Revert Process**: Return to the appropriate step in the workflow
4. **Update Documentation**: Ensure Hikakaku CMS is updated with the new information
5. **Resume Workflow**: Continue from the corrected step

### Common Error Scenarios

| Error Type | Detection Point | Resolution Approach |
| ---------- | --------------- | ------------------- |
| Incomplete Requirements | Step 3 or 4 | Return to Step 2 for clarification |
| Missing Test Cases | Step 5 | Return to Step 3 to add test cases |
| Architectural Issues | Step 5 | Return to Step 4 to revise solution |
| Implementation Bugs | CI/CD | Fix in Step 5 before proceeding |
| Performance Issues | Testing | Revisit Step 4 for optimization strategy |

## 📋 Templates Reference

Each step in the workflow has templates defined in the corresponding rule files and in the Hikakaku CMS structure:

- **Specification Template (Step 2)**: Refer to `.cursor/knowledge/structure/feature-specification/template.md`
- **Test Case Template (Step 3)**: Defined in `.cursor/rules/2-test-case--agent.mdc` under "Suggested Test Case Formats"
- **Technical Solution Template (Step 4)**: Defined in `.cursor/rules/3-tech-lead--agent.mdc` under "Expected Deliverables"

**Important:** Always use the templates defined in the rule files and Hikakaku CMS structure to ensure consistency.

## 📁 Feature Documentation Storage

When creating or updating feature documentation:

1. **Create New Feature File**: For each new feature, create a dedicated file in `.cursor/knowledge/structure/feature-specification/` based on the template:
   - Use the template at `.cursor/knowledge/structure/feature-specification/template.md`
   - Name the file descriptively, e.g., `user-authentication.md`
   - Include all required sections: Status, Business Requirements, TODO List, Active Decisions, Technical Solution, Data Flow, Security Patterns, and Test Cases

2. **Update Index File**: After creating or updating a feature file, always update the index file:
   - File location: `.cursor/knowledge/structure/feature-specification/index.md`
   - The index contains a table with columns: Feature, Status, Last Updated, File Context Link
   - Add a new row for new features or update existing rows for modified features

3. **Hikakaku CMS Updates**: After each workflow step, update both:
   - The feature-specific file with new information from that step
   - The index file to reflect the current status

This storage structure ensures all feature information is properly documented and easily accessible through the Hikakaku CMS knowledge system.

## 🔍 GitHub Integration Best Practices

When working with GitHub in Step 5:

1. **Branch Naming**: Use `feature/[feature-name]` for feature branches
2. **Commit Messages**: Follow the format `[Feature] Brief description of changes`
3. **PR Description**: Include:
   - Feature overview
   - Implementation approach
   - Testing performed
   - Screenshots/demos if applicable
4. **CI/CD Monitoring**: Address any CI failures before requesting review
5. **Code Review**: Respond to all review comments with appropriate fixes
6. **Repository Rules**: For changes to files in the `.cursor` directory, only create PRs for the hikakaku-cms repository
7. **Draft PRs**: Always create PRs as draft PRs first, especially for documentation changes, to allow for proper review before they are ready to be merged

## 🔍 Quality Checklist Enforcement

The workflow includes manual quality checklists to ensure documentation completeness before step transitions:

1. **Documentation Verification**: Technical Leads must verify:
   - Required sections for each step are present
   - Feature is properly indexed
   - Documentation follows template structure

2. **Step Transition Validation**:
   - Quality checklist must be reviewed before step transition
   - Step transition is blocked if documentation is incomplete
   - Technical Lead provides specific feedback on missing elements

3. **Integration with PR Process**:
   - PR reviews include documentation quality assessment
   - Technical Lead reviews are blocked until quality checklists pass
   - Documentation quality is considered as important as code quality

## 📝 Workflow Process for Future Sessions

To ensure consistency across all sessions and prevent common mistakes:

1. **Documentation Language**: All documentation in the `.cursor` directory must be written in English, not Vietnamese
2. **Consolidated Documentation**: All documentation for a feature must be consolidated in a single file at `.cursor/knowledge/structure/feature-specification/[feature-name].md`
3. **Repository Rules**: 
   - Only create PRs for the hikakaku-cms repository for changes to files in the `.cursor` directory
4. **Documentation Structure**: Follow the template structure with all required sections as defined in `.cursor/knowledge/structure/feature-specification/template.md`
5. **Step Completion**: Always wait for explicit confirmation before proceeding to the next step
