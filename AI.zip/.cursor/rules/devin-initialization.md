# Devin Initialization Guide

## Workflow Process Requirements

**IMPORTANT: Always follow the 5-step workflow process for all tasks**

When starting a new session with Devin, you must:

1. **Read the workflow document first**: Always read `.cursor/rules/0-work-flow-manual-devin.md` at the beginning of every session
2. **Follow the 5-step process strictly**:
   - Step 1: Hikakaku CMS - Load project knowledge only (NO CODE CHANGES)
   - Step 2: Clear Spec - Documentation only (NO CODE CHANGES)
   - Step 3: Test Case - Write test cases only (NO CODE CHANGES)
   - Step 4: Tech Lead - Design technical solution only (NO CODE CHANGES)
   - Step 5: Developer - Only implement code after completing steps 1-4 with explicit approval

3. **Wait for explicit confirmation**: Never proceed to the next step without explicit user confirmation
4. **Never create PRs without approval**: Do not create pull requests until explicitly instructed
5. **Always use PR template**: When creating PRs, always use the template from `.github/pull_request_template.md`
6. **Document each step thoroughly**: Create documentation for each step before proceeding

## Initialization Checklist

When starting a new session:

- [ ] Read `.cursor/rules/0-work-flow-manual-devin.md`
- [ ] Confirm understanding of the 5-step workflow process
- [ ] Ask which step to start with if not explicitly stated
- [ ] Refuse to implement code changes before completing steps 1-4
- [ ] Get explicit confirmation before proceeding to each next step

## Error Prevention

Common mistakes to avoid:
- Creating PRs without following the workflow process
- Creating PRs without first confirming content with the user
- Using incorrect branch naming convention (should be `feature/[feature-name]`, e.g., `feature/user-authentication`)
- Using incorrect commit message format (should be `[Feature] Brief description`, e.g., `[User Authentication] Add login form validation`)
- Implementing code changes before completing documentation steps
- Proceeding to the next step without explicit confirmation
- Making autonomous decisions without user approval
- Creating PRs for files in the `.cursor` directory for repositories other than hikakaku-cms

Remember: Steps 1-4 are "Document only, no code" - coding is only allowed in step 5 after explicit approval.
