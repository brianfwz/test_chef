# Codebase Overview
- For responsibility, only describe main methods that need to be explained and help to me understand the main purpose of the class.
- Only describe special or complex arguments that need explanation. Basic arguments like id, created_at are self-explanatory and don't require descriptions.

## 1. Background Jobs

### 1.1 csv_import_job.rb
- **Responsibility**: Manages CSV import for various data types (shops, store accounts, items)
- **Highlighted Methods**:
  + `perform(file_path, options = {})` - Execute the CSV import process
  + `handle_error(error, context)` - Process and log import errors
  + `validate_csv(file)` - Validate CSV format and required columns

### 1.2 send_estimate_mail_reply_job.rb
- **Responsibility**: Handles sending email replies for estimates
- **Highlighted Methods**:
  + `perform(estimate_id, reply_data)` - Send estimate reply email
  + `format_reply(reply_data)` - Format reply content for email

## 2. Services

### 2.1 price_history_service.rb
- **Responsibility**: Manages price tracking and history for items
- **Highlighted Methods**:
  + `track_price_changes(item, new_price)` - Record price changes
  + `calculate_price_stats(item)` - Calculate price statistics
  + `get_price_history(item, period)` - Get price history for specified period

### 2.2 invoice_service.rb
- **Responsibility**: Handles invoice generation and processing
- **Highlighted Methods**:
  + `generate_invoice(store, period)` - Generate invoice for store
    * `period`: Hash containing start_date and end_date
  + `calculate_fees(store_activities)` - Calculate fees based on store activities
  + `process_payment(invoice, payment_data)` - Process invoice payment

## 3. Models

### 3.1 store.rb
- **Responsibility**: Represents a store in the system with its profile, contracts, and activities
- **Highlighted Methods**:
  + `active_contract` - Get current active contract
  + `calculate_monthly_stats` - Calculate store performance statistics
  + `handle_click_transfer(click_data)` - Process click transfer tracking

### 3.2 item.rb
- **Responsibility**: Manages item data and relationships with categories and prices
- **Highlighted Methods**:
  + `update_price(price_data)` - Update item price with validation
  + `build_from_estimate(estimate)` - Create item from estimate data
  + `search_by_category(category_id)` - Search items in specific category

## 4. Controllers

### 4.1 api/reviews_controller.rb
- **Responsibility**: Handles API endpoints for review management
- **Highlighted Methods**:
  + `create(review_params)` - Create new review with validation
    * `review_params`: Hash containing review data (title, content, rating)
  + `update_status(id, status)` - Update review status (published, pending, rejected)
  + `get_store_reviews(store_id, filters)` - Get reviews for specific store

### 4.2 api/shops_controller.rb
- **Responsibility**: Manages shop-related API endpoints
- **Highlighted Methods**:
  + `register(shop_params)` - Register new shop with validation
  + `update_profile(id, profile_data)` - Update shop profile
  + `get_statistics(id, period)` - Get shop performance statistics

## 5. Concerns

### 5.1 suspicious_markable.rb
- **Responsibility**: Provides functionality to mark and handle suspicious content
- **Highlighted Methods**:
  + `mark_as_suspicious(reason)` - Mark content as suspicious
  + `review_suspicious_mark(admin_id)` - Review and handle suspicious mark
  + `get_suspicious_history` - Get history of suspicious marks

### 5.2 prefecture_est_mail_countable.rb
- **Responsibility**: Manages prefecture-based estimate email counting
- **Highlighted Methods**:
  + `increment_mail_count(prefecture_id)` - Increment mail count for prefecture
  + `get_prefecture_stats(period)` - Get prefecture-wise statistics
