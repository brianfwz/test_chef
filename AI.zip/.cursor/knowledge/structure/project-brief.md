# Project Brief: Hikakaku CMS

## Core Requirements
1. **Price Comparison Platform**
   - Manage and compare buying prices across different stores
   - Track historical price data and market trends
   - Support multiple product categories:
     - Electronics and games
     - Books and media
     - Watches and luxury items
     - Vehicles (assessment system)
     - Pawn shop items
     - Recycle items
     - C2C (Customer to Customer) items

2. **Store Management**
   - Store registration and profile management
   - Contract and category-based agreements
   - Review and rating system
   - Store performance analytics
   - Click tracking and access analytics
   - Store information request system
   - Store update management

3. **User Experience**
   - Intuitive price comparison interface
   - Comprehensive estimate form system
   - Q&A platform for user inquiries
   - Mobile-responsive design (jpmobile)
   - Multi-language support (focusing on Japanese)
   - Line Bot integration for user interaction
   - SMS notifications via Twilio
   - Email communications via Mailgun

## Project Goals
1. **Market Leadership**
   - Become the leading price comparison platform for second-hand goods
   - Build trust through transparent pricing and reviews
   - Expand store network across various categories
   - Enhance user engagement through Q&A and reviews

2. **Technical Excellence**
   - High-performance search with Elasticsearch
   - Scalable architecture for growing data
   - Robust security and data protection
   - Efficient content management system
   - Comprehensive notification system

3. **System Architecture**
   - Modular design with clear separation of concerns
   - REST API architecture
   - Optimized database design for price tracking
   - Efficient caching with Redis
   - Background processing with Sidekiq
   - PDF generation capabilities
   - QR code integration

## User Experience Goals
1. **Seamless Navigation**
   - Fast and responsive interface
   - Intuitive search and filtering
   - Clear price comparison visualization
   - Easy access to store information
   - Efficient estimate form submission
   - Interactive Q&A system
   - Bot-assisted navigation

2. **Content Management**
   - Efficient blog and content publishing
   - SEO-optimized content structure
   - Rich media support with Carrierwave
   - Version control for content
   - Suspicious content detection
   - Mobile-optimized content delivery

## Technical Features
1. **Core Platform**
   - Ruby on Rails backend
   - React-based frontend components
   - REST APIs with versioning
   - Elasticsearch for advanced search
   - Redis for caching
   - Sidekiq for background jobs
   - Carrierwave for file uploads
   - Prawn for PDF generation
   - RQRCode for QR codes

2. **Integration Features**
   - Line Bot API integration
   - Mailgun for email delivery
   - Twilio for SMS
   - Chatwork integration
   - Slack integration
   - Analytics integration
   - Social media integration

## Security
- **Authentication and Authorization**
  - Role-based access control (Pundit)
  - Secure API authentication (Devise)
  - Data encryption (attr_encrypted)
  - API key management
  - Audit logging
  - IP filtering (rack-user_agent)
  - Bot detection (browser gem)
  - Suspicious activity monitoring

## Project Scope
- **In Scope:**
  - Price comparison engine
  - Store management system
  - Review and rating system
  - Content management system
  - Estimate form system
  - Q&A platform
  - API integration endpoints
  - Analytics and reporting
  - Monitoring and logging
  - SEO optimization
  - Mobile responsiveness
  - Line Bot integration
  - SMS notifications
  - PDF generation
  - QR code generation

- **Out of Scope:**
  - Direct payment processing
  - Inventory management
  - Physical store operations
  - Customer support system
  - Direct messaging between users
  - Real-time chat
  - User-to-user transactions

## Success Metrics
1. **System Performance**
   - Response time under 500ms for main operations
   - 99.9% uptime
   - Efficient resource utilization
   - Elasticsearch query performance
   - Background job completion rates

2. **User Engagement**
   - Increased user retention
   - Higher store participation
   - Growing review contributions
   - Q&A platform activity
   - Estimate form completion rates
   - Bot interaction success rates

3. **Business Metrics**
   - Store contract conversion rates
   - Category coverage growth
   - Price data accuracy
   - Store response times
   - Review quality metrics

4. **Technical Quality**
   - Comprehensive test coverage
   - Clear documentation
   - Maintainable code
   - Efficient deployment process
   - Security compliance
   - API performance
   - Mobile compatibility
