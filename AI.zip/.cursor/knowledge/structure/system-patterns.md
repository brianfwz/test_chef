# System Patterns

## Architecture Overview

### Data Flow Patterns
1. **Model Layer Patterns**
   - Concerns for reusable behaviors
   - Service objects for complex business logic
   - Form objects for complex form handling
   - Validators for data validation
   - Uploaders for file handling

2. **Service Layer Patterns**
   - Price tracking services
   - Invoice processing services
   - Redis caching services
   - Access counting services
   - Category management services

3. **Background Processing Patterns**
   - CSV import/export jobs
   - Price management jobs
   - Notification jobs
   - Analytics jobs
   - Geocoding jobs

### Core Design Patterns

1. **Model Concerns**
   - Suspicious content detection (`suspicious_markable.rb`, `suspicious_review_mixin.rb`)
   - Data validation (`email_validatable.rb`, `telephone_number_validatable.rb`)
   - Data masking (`maskable.rb`)
   - Location handling (`with_location_range_searchable.rb`)
   - Version control (`versioned_association.rb`)

2. **Service Objects**
   - Price history tracking (`price_history_service.rb`)
   - Invoice processing (`invoice_service.rb`)
   - Redis caching (`redis_service.rb`)
   - Access counting (`access_counter_service.rb`)
   - Category management (`category_service.rb`)

3. **Job Processing**
   - CSV data imports
   - Price updates and alerts
   - Review moderation
   - Analytics aggregation
   - Email and notification delivery

## Security Patterns

1. **Data Protection**
   - Sensitive data encryption (`attr_encrypted`)
   - Safe data assignment (`safe_assignable.rb`)
   - Sensitive photo handling (`sensitive_photo_treatable.rb`)
   - IP and user agent filtering
   - Bot detection

2. **Access Control**
   - Role-based authorization (Pundit)
   - API authentication (Devise)
   - Request rate limiting
   - Suspicious activity monitoring
   - Data masking for sensitive information

3. **Input Validation**
   - Form validation
   - Email validation
   - Phone number validation
   - Postal code validation
   - Line ID validation

## Performance Patterns

1. **Caching Strategy**
   - Deep caching (`deep_cache.rb`)
   - Redis for data caching
   - Fragment caching for views
   - Query result caching
   - Counter caching

2. **Background Processing**
   - Sidekiq for async jobs
   - CSV import processing
   - Email delivery
   - Analytics calculation
   - Price updates

3. **Database Optimization**
   - Batch processing
   - Counter culture for counters
   - Elasticsearch for search
   - Efficient associations
   - Query optimization

4. **API Performance**
   - Request rate limiting
   - Response caching
   - Batch operations
   - Pagination
   - Efficient serialization

## Monitoring Patterns

1. **Application Monitoring**
   - New Relic integration
   - Sentry error tracking
   - Slow query logging
   - Exception notification
   - Custom metrics tracking

2. **Job Monitoring**
   - Sidekiq dashboard
   - Job status tracking
   - Job retry handling
   - Job performance metrics
   - Error notification

3. **Business Metrics**
   - Access counting
   - Price tracking
   - User engagement
   - Store performance
   - Review quality

## Data Management Patterns

1. **Import/Export**
   - CSV processing
   - Batch operations
   - Data validation
   - Error handling
   - Progress tracking

2. **Version Control**
   - Content versioning
   - Change tracking
   - History recording
   - Audit logging
   - Rollback capability

3. **Data Validation**
   - Form validation
   - Data sanitization
   - Format checking
   - Relationship validation
   - Business rule validation
