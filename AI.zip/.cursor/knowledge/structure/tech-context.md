# Technical Context

## Technology Stack

### Core Technologies
- Ruby 3.0.5
- Rails 6.0.x
- MySQL (mysql2 ~> 0.5.5)
- Redis & Sidekiq
- Elasticsearch 7.1.x
- Unicorn & Unicorn Worker Killer

### Development Tools
- Git
- RSpec & RSpec Rails
- Rubocop with extensions:
  - rubocop-rails
  - rubocop-performance
  - rubocop-rspec
- Bullet for N+1 detection
- Better Errors & Web Console

### External Systems
- **AWS Services:**
  - S3 for file storage
  - SQS for message queuing
  - SES for email backup
- **Communication Services:**
  - Mailgun for primary email
  - Twilio for SMS
  - Slack & Chatwork for notifications
- **OAuth Providers:**
  - Google OAuth2
  - Yahoo Japan
  - LINE

### Project Structure
```
app/
├── assets/         # Frontend assets
├── channels/       # Action Cable channels
├── controllers/    # Request handlers
├── crawler/        # Web crawling logic
├── forms/          # Form objects
├── handlers/       # Custom handlers
├── helpers/        # View helpers
├── jobs/          # Background jobs (Sidekiq)
├── mailers/       # Email templates
├── models/        # Data models
├── pdfs/          # PDF generation (Prawn)
├── policies/      # Pundit policies
├── resources/     # API resources
├── services/      # Business logic services
├── uploaders/     # Carrierwave uploaders
├── validators/    # Custom validators
├── view_objects/  # View presenters
└── views/         # View templates (Slim)

config/            # Rails configuration
├── environments/  # Environment configs
├── initializers/  # Rails initializers
├── locales/      # I18n translations
└── settings/     # App settings (config gem)

db/               # Database migrations
lib/              # Extended libraries
spec/             # Test files
```

### Environment Configuration
- `dotenv-rails` for environment variables
- `config` gem for application settings
- Environment-specific configurations

## Dependencies

### Key Gems
- Authentication & Authorization:
  - Devise
  - Pundit
  - OAuth providers (Google, Yahoo, LINE)
- Background Processing:
  - Sidekiq
  - Redis suite
- File Storage:
  - Carrierwave
  - AWS SDK (S3, SQS, SES)
  - MiniMagick
- Frontend:
  - Slim & Slim Rails
  - Bootstrap Sass
  - jQuery & jQuery UI
  - React Rails
  - Minipack
- PDF & QR:
  - Prawn & Prawn Table
  - RQRCode
- API & Integration:
  - Line Bot API
  - Rack CORS
  - HTTParty
  - Jpmobile
- Monitoring:
  - New Relic
  - Sentry
  - Exception notifiers (Slack, Chatwork)

### Database Features
- MySQL for primary storage
- Redis for caching
- Elasticsearch for search
- Features:
  - Soft deletes (Paranoia)
  - Encrypted attributes (attr_encrypted)
  - Counter culture
  - Acts as taggable
  - Ancestry for trees

### API Integration
- REST API endpoints
- OAuth authentication
- Rate limiting
- CORS support
- Mobile detection (jpmobile)

### Performance
- Background job processing (Sidekiq)
- Redis caching
- N+1 query detection (Bullet)
- Query optimization

### Security
- Devise authentication
- OAuth integration
- Pundit authorization
- CSRF protection
- Encrypted attributes (attr_encrypted)
- IP filtering (rack-user_agent)
- Bot detection (browser gem)

### Monitoring
- New Relic APM
- Sentry error tracking
- Exception notification (Slack, Chatwork)
- Sidekiq monitoring

## Development Setup

### Prerequisites
- Ruby 3.0.5
- MySQL 8.0
- Redis 5.2
- Elasticsearch 7.1.x
- Node.js & Yarn

### Docker Setup
- `docker-compose.yml` for services
- `Dockerfile` for application
- Services:
  - Web (Unicorn)
  - MySQL
  - Redis
  - Elasticsearch
  - Sidekiq

## Tool Usage Patterns

### Git Workflow
1. Feature branches
2. Code review process
3. CI/CD pipeline

### Testing Strategy
1. Unit tests (RSpec)
2. Integration tests (Capybara)
3. System tests (Selenium)
4. Factory Bot for fixtures
5. Crawler testing (Capybara, Nokogiri)

### Code Quality
1. Rubocop for style checking
2. Code review guidelines
3. Documentation requirements
4. Rails Best Practices

## Monitoring and Logging

### Application Monitoring
- New Relic APM
- Sentry error tracking
- Resource monitoring
- Custom metrics
- Exception notification (Slack, Chatwork)

### Job Monitoring
- Sidekiq dashboard
- Job status tracking
- Error handling
- Dead job management

### Logging
- Application logs
- Background job logs
- Error logs
- Exception tracking
- Structured logging

### Database
- MySQL monitoring
- Query logging
- Slow query tracking

### Flow/Chart
- Use Mermaid for chart, Example:
```mermaid
flowchart TD
    A[Request] --> B[Authentication]
    B --> C[Authorization]
    C --> D[Processing]
    D --> E[Background Jobs]
    D --> F[Response]
```
