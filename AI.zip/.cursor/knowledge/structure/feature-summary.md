# Feature Summary

## 1.1 Frontend Applications

### API Authentication
#### What Is This?
- Authentication system using Devise
- CSRF token management
- OAuth integration (Google, Yahoo, LINE)
- Session management and security
- User locking system

Key Models:
- User: Core user authentication
- UserLockReason: Track user lock reasons
- UserLockToken: Manage lock tokens
- UserDailyMyPageAccessLog: Track user access

#### How To Use?
- Implement Devise authentication
- Handle CSRF protection
- Manage OAuth flows
- Track user sessions and access
#### Solution / Architecture Design
```mermaid
flowchart TD
    A[API Auth] --> B[Devise Auth]
    A --> C[OAuth Integration]
    A --> D[Security]
    
    B --> B1[User Auth]
    B --> B2[Session]
    B --> B3[Tokens]
    
    C --> C1[Google]
    C --> C2[Yahoo]
    C --> C3[LINE]
    
    D --> D1[CSRF]
    D --> D2[User Locks]
    D --> D3[Access Logs]
```

### API Endpoints
#### What Is This?
- RESTful API endpoints
- Estimate form system
- Store management APIs
- Category and item APIs
- Review and blog APIs

Key Controllers:
- EstimateFormsController: Handle estimate forms
- StoreEstimateFormsController: Store-specific estimates
- CategoryController: Category management
- BlogController: Blog content management
- ReviewsController: Review management

#### How To Use?
- Follow RESTful conventions
- Handle authentication
- Manage form submissions
- Process API responses
#### Solution / Architecture Design
```mermaid
flowchart TD
    A[API Endpoints] --> B[Estimates]
    A --> C[Store]
    A --> D[Content]
    
    B --> B1[Form Processing]
    B --> B2[Validation]
    B --> B3[Response]
    
    C --> C1[Management]
    C --> C2[Analytics]
    C --> C3[Reviews]
    
    D --> D1[Blog]
    D --> D2[Categories]
    D --> D3[Items]
```

## 1.2 Store Management

### What Is This?
- Store profile and registration management
- Contract and agreement handling
- Store authentication and authorization
- Store communication system
- Analytics and performance tracking
- Review request system

Key Models:
- Store: Core store data and relationships
- StoreContract: Store contract and settings
- StoreFile: Store-related file management
- StoreUpdateRequest: Handle store updates
- StoreInfoRequest: Information requests
- StoreAccessCount: Access analytics
- StoreClickTransfer: Click tracking
- StoreReviewRequestMailBody: Review requests
- StoreClickStatusLog: Click analytics
- StoreName: Store naming management
- StoreNote: Store annotations

### How To Use?
1. Store Registration:
   - Register store with required information
   - Set up store profile and settings
   - Configure contract details
   - Set up category relationships

2. Store Management:
   - Manage store profile and settings
   - Handle store authentication
   - Configure notifications
   - Manage category contracts
   - Track performance metrics

3. Store Analytics:
   - Monitor access counts
   - Track click transfers
   - Analyze performance
   - Generate reports

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Store Management] --> B[Core]
    A --> C[Analytics]
    A --> D[Communication]
    
    B --> B1[Profile]
    B --> B2[Contracts]
    B --> B3[Updates]
    
    C --> C1[Access]
    C --> C2[Clicks]
    C --> C3[Performance]
    
    D --> D1[Reviews]
    D --> D2[Requests]
    D --> D3[Notifications]
```

## 1.3 Item Management

### What Is This?
- Item catalog management system
- Category organization and hierarchy
- Price tracking and history
- Item metadata management
- Vehicle and pawn items
- Recycle items management

Key Models:
- Item: Core item data
- Category: Category system
- ItemPhoto: Item images
- VehicleItem: Vehicle-specific items
- RecycleCategoryRelation: Recycle categories
- PawnCategoryRelation: Pawn categories
- CategoryRelation: Category relationships
- ImportCategory: Category imports
- ImportCategoryGroup: Category grouping

### How To Use?
1. Item Management:
   - Create and update items
   - Manage categories
   - Handle item photos
   - Process special items

2. Category Management:
   - Manage category hierarchy
   - Handle category imports
   - Configure relationships
   - Set up groupings

3. Special Items:
   - Vehicle assessment
   - Pawn management
   - Recycle processing

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Item Management] --> B[Items]
    A --> C[Categories]
    A --> D[Special]
    
    B --> B1[Core Data]
    B --> B2[Photos]
    B --> B3[Metadata]
    
    C --> C1[Hierarchy]
    C --> C2[Imports]
    C --> C3[Relations]
    
    D --> D1[Vehicles]
    D --> D2[Pawns]
    D --> D3[Recycle]
```

## 1.4 Price Management

### What Is This?
- Price tracking system
- Market price calculation
- Price history tracking
- Price statistics
- Priceable items management

Key Models:
- Price: Core price data
- PriceableMaster: Price master data
- PriceableStat: Price statistics
- Priceable: Price functionality
- HighestPriceHistory: Price history

### How To Use?
1. Price Tracking:
   - Track item prices
   - Record price history
   - Calculate market prices
   - Generate statistics

2. Price Analysis:
   - Monitor price trends
   - Compare market prices
   - Analyze statistics
   - Generate reports

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Price Management] --> B[Core]
    A --> C[Analysis]
    A --> D[History]
    
    B --> B1[Prices]
    B --> B2[Masters]
    B --> B3[Stats]
    
    C --> C1[Trends]
    C --> C2[Market]
    C --> C3[Reports]
    
    D --> D1[Tracking]
    D --> D2[Changes]
    D --> D3[Archives]
```

## 1.5 Review System

### What Is This?
- Review management system
- Rating and feedback
- Review moderation
- Store responses
- Review analytics
- Suspicious review detection

Key Models:
- Review: Core review data
- ReviewReply: Store responses
- ReviewUserFeedback: User feedback
- SuspiciousReview: Suspicious detection
- ReviewMagiUser: Special users
- ReviewUndeliverableEmail: Failed emails
- PickupReview: Featured reviews

### How To Use?
1. Review Management:
   - Handle review submissions
   - Process ratings
   - Moderate content
   - Manage responses

2. Review Features:
   - Feature reviews
   - Track feedback
   - Monitor suspicious activity
   - Handle notifications

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Review System] --> B[Core]
    A --> C[Moderation]
    A --> D[Features]
    
    B --> B1[Reviews]
    B --> B2[Replies]
    B --> B3[Feedback]
    
    C --> C1[Suspicious]
    C --> C2[Validation]
    C --> C3[Emails]
    
    D --> D1[Pickup]
    D --> D2[Special]
    D --> D3[Analytics]
```

## 1.6 Blog System

### What Is This?
- Blog content management
- AMP support
- Blog rankings
- Content moderation
- Media management
- SEO optimization

Key Controllers:
- BlogController: Main blog management
- BlogAmpController: AMP pages
- BlogRankingsController: Rankings
- BlogSupervisorsController: Supervision

Key Models:
- Blog: Core blog content
- SuspiciousBlogComment: Comment moderation
- NewsEmbeddedImage: Blog images
- News: News content

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Blog System] --> B[Content]
    A --> C[Features]
    A --> D[Management]
    
    B --> B1[Posts]
    B --> B2[Images]
    B --> B3[News]
    
    C --> C1[AMP]
    C --> C2[Rankings]
    C --> C3[SEO]
    
    D --> D1[Moderation]
    D --> D2[Supervision]
    D --> D3[Analytics]
```

## 1.7 Analytics & Reporting

### What Is This?
- Performance tracking
- Sales analytics
- User behavior analysis
- Store performance
- Click tracking
- Access logging

Key Models:
- UserDailyMyPageAccessLog: User access
- StoreClickStatusLog: Click tracking
- SalesData: Sales analytics
- SalesRepAssignment: Sales management
- StoreAccessCount: Store analytics
- MailTracking: Email analytics

### Solution / Architecture Design
```mermaid
flowchart TD
    A[Analytics] --> B[Access]
    A --> C[Sales]
    A --> D[Performance]
    
    B --> B1[User Logs]
    B --> B2[Store Logs]
    B --> B3[Click Logs]
    
    C --> C1[Data]
    C --> C2[Reports]
    C --> C3[Assignments]
    
    D --> D1[Metrics]
    D --> D2[Tracking]
    D --> D3[Analysis]
```
